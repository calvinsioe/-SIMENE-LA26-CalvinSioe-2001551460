package Tugas2;

import java.util.Scanner;

public class MyClassFibonacci {
	
	public static void main (String [] args){
	Scanner scan = new Scanner(System.in);



		
		

		        int n = 4200, t1 = 0, t2 = 1;
		       
		        System.out.print("20 bilangan fibonacci: ");
		        while (t1 <= n)
		        {
		            System.out.print(t1 + " + ");

		            int sum = t1 + t2;
		            t1 = t2;
		            t2 = sum;
		        }
		    }
		
	}
	
	

	
		
	


