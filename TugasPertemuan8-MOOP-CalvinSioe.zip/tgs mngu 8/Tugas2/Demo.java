package Tugas2;

public class Demo {

}
