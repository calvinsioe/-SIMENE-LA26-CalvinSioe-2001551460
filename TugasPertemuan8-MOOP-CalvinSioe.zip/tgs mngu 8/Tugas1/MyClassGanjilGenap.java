package Tugas1;
import java.util.Scanner;
public class MyClassGanjilGenap implements Runnable{
	Scanner scan=new Scanner(System.in);
	int angkaganjilgenap;

	@Override
	public void run() {
		System.out.println("Input angka [Ganjil atau Genap]:");
		angkaganjilgenap= scan.nextInt(); scan.nextLine();
		if(angkaganjilgenap % 2 == 0){
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} //4000 artinya 4 second
			System.out.println("Angka yang di input adalah genap");
		}else{
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} //4000 artinya 4 second
			System.out.println("Angka yang di input adalah ganjil");
		}
		
		
		
		
		
		
	}
}//public







/*import java.util.Scanner;
public class MyClassGanjilGenap {
	
	
		
	String name;
	static Scanner scan = new Scanner (System.in);
	static int angka;
	
	
	
	public MyClassGanjilGenap() {
		
		
	}

	public static void main(String[] args) {
		
	}
	
	
	public static void insertData() throws InterruptedException {
		System.out.println("Input angka [Ganjil atau Genap]:");
		angka= scan.nextInt(); scan.nextLine();
		if(angka % 2 == 0){
			Thread.sleep(4000); //4000 artinya 4 second
			System.out.println("Angka yang di input adalah genap");
		}else{
			Thread.sleep(4000); //4000 artinya 4 second
			System.out.println("Angka yang di input adalah ganjil");
		}
			
		
	}
	
	
	
	
	
	
	
	

}*/

