package Tugas1;

import java.util.Scanner;

public class MyClassFibonacci implements Runnable {
 
	public void run() {
		Scanner reader = new Scanner(System.in);
		try {
			Thread.sleep(9000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Enter a number");
		// read the number to be checked
		int numberToCheck = reader.nextInt();
		// close the reader
		reader.close();
		int firstNumber = 0, secondNumber = 1, fibonacciNumber = 0;
		// loop till the current fibonacci number is less than the number to
		// check
		while (fibonacciNumber < numberToCheck) {
			// calculate the next fibonacci number
			fibonacciNumber = firstNumber + secondNumber;
			// move the fibonacci series ahead
			firstNumber = secondNumber;
			secondNumber = fibonacciNumber;
		}
		// compare the current fibonacci number with number to check
		if (numberToCheck == fibonacciNumber) {
			try {
				Thread.sleep(9000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Number belongs to Fibonacci series");
		} else {
			try {
				Thread.sleep(9000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Number does not belong to Fibonacci series");
		}
	}

	//@Override
	//public void run() {
		// TODO Auto-generated method stub
		
	}
//}





























/*import java.util.Scanner;

public class MyClassFibonacci implements Runnable {
	Scanner scan = new Scanner(System.in);

	@Override
	public void run() {
		
		

		        int n = 4200, t1 = 0, t2 = 1;
		        try {
					Thread.sleep(9000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        System.out.print("20 bilangan fibonacci: ");
		        while (t1 <= n)
		        {
		            System.out.print(t1 + " + ");

		            int sum = t1 + t2;
		            t1 = t2;
		            t2 = sum;
		        }
		    }
		
	}*/
	
	

	
		
	


